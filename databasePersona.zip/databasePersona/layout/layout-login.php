<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<link href="./css/style.css" rel=stylesheet>
</head>

<body>
	<div id="main_container">
		<div id="top">
			<h1>Benvenuto!</h1>
		</div>
		
		
		<div id="main-2">
				<?php echo $content ?>
		</div>
	</div>
</body>
</html>
