<html>
	<head>
		<title>LOGIN</title>
	</head>
	<body>
		<center>
		<form action="?controller=login" method="POST">
			<center>
			<input type="hidden" name="action" value="doLogin">
			<p>Utente:</p>
			<input type="text" name="username">
			<p>password:</p>
			<input type="password" name="password">
			</center>
			<br>
			<br>
			<input type="submit" value="VAI">
		</form>
		</center>
	</body>
</html>
