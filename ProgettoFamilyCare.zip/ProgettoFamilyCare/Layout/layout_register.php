<!DOCTYPE html>
<html>
	<head>
		<link href="../Web/CSS/stile.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>

		<div class="container">
			<article>
			  <?php echo $content ?>
			</article>

		</div>
	</body>
</html>
