<!DOCTYPE html>
<html>
	<head>
		<link href="../Web/CSS/stile.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>

		<div class="container">
			
			<header>
			   <h1>ACCEDI</h1>
			</header>
			<nav>
				<p>Non sei registrato? <a href="index.php?controller=login&action=register">Registrati!</a></p>
			</nav>
			<article>
			  <?php echo $content ?>
			</article>

		</div>
	</body>
</html>
