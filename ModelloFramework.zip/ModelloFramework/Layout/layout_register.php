<!DOCTYPE html>
<html>
	<head>
		<link href="../Web/CSS/stile.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>

		<div class="container">
			
			<header>
			   <h1>REGISTRATI</h1>
			</header>
			<nav>
				<p>Sei già registrato? <a href="index.php?controller=login&action=login">Accedi!</a></p>
			</nav>
			<article>
			  <?php echo $content ?>
			</article>

		</div>
	</body>
</html>
